data {
  int<lower=0> N;  // Number of observations
  int<lower=1> K;  // Number of covariates
  int<lower=1> L;  // Number of levels
  array[N] int<lower=0, upper=1> y; // Observations
  array[N] row_vector[K] X; // Covariates
  array[N] int<lower=1, upper=L> ll; // Level index
}

parameters {
  array[K] real mu;
  array[K] real<lower=0> sigma;
  array[L] vector[K] beta;
}

model {
  vector[N] x_beta_ll;
  mu ~ normal(0, 2.5);
  sigma ~ exponential(1);
  for (l in 1:L) {
    beta[l] ~ normal(mu, sigma);
  }
  for (n in 1:N) {
    x_beta_ll[n] = X[n] * beta[ll[n]];
  }
  y ~ bernoulli_logit(x_beta_ll);
}

generated quantities {
  vector[N] log_lik;
  for (n in 1:N) {
    log_lik[n] = bernoulli_logit_lpmf(y[n] | X[n] * beta[ll[n]]);
  }
}
