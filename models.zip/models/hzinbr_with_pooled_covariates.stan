functions {
  // Zero inflated negative binomial log likelikhood
  real zinb_lpmf(int y,
                 real lambda,
                 real recip_theta,
                 real p) {
    real theta = 1. / recip_theta;
    if (y == 0) {
      return log_sum_exp(
        bernoulli_logit_lpmf(1 | p),
        bernoulli_logit_lpmf(0 | p) + neg_binomial_2_log_lpmf(0 | lambda, theta)
      );
    } else {
      return bernoulli_logit_lpmf(0 | p) +
        neg_binomial_2_log_lpmf(y | lambda, theta);
    }
  }
}

data {
  int<lower=0> N; // Number of data points
  int<lower=0> K; // Number of covariates
  int<lower=0> K_p; // Number of pooled covariates
  int<lower=1> L;  // Number of levels
  int y[N];  // Observations
  array[N] row_vector[K] X; // Covariated
  array[N] row_vector[K_p] X_p; // Pooled covariates
  array[N] int<lower=1, upper=L> ll; // Level index
}

parameters {
  vector[K] mu_z;
  vector<lower=0>[K] sigma_z;
  array[L] vector[K] beta_z_std;
  vector[K_p] beta_z_p;
  vector[K] mu_c;
  vector<lower=0>[K] sigma_c;
  array[L] vector[K] beta_c_std;
  real recip_theta;
}

transformed parameters {
  array[L] vector[K] beta_z;
  array[L] vector[K] beta_c;
  for (l in 1:L) {
    beta_z[l] = beta_z_std[l] .* sigma_z + mu_z;
    beta_c[l] = beta_c_std[l] .* sigma_c + mu_c;
  }
}

model {
  recip_theta ~ exponential(1);
  mu_z ~ normal(0, 2.5);
  sigma_z ~ exponential(1);
  mu_c ~ normal(0, 2.5);
  sigma_c ~ exponential(1);
  beta_z_p ~ normal(0, 2.5);
  for (l in 1:L) {
    beta_z_std[l] ~ std_normal();
    beta_c_std[l] ~ std_normal();
  }
  for ( n in 1:N ) {
    target += zinb_lpmf(
      y[n] |
      X[n] * beta_c[ll[n]],
      recip_theta,
      X[n] * beta_z[ll[n]] + X_p[n] * beta_z_p
    );
  }
}

generated quantities {
  vector[N] log_lik;
  for ( n in 1:N ) {
    log_lik[n] = zinb_lpmf(
      y[n] |
      X[n] * beta_c[ll[n]],
      recip_theta,
      X[n] * beta_z[ll[n]] + X_p[n] * beta_z_p
    );
  }
}
