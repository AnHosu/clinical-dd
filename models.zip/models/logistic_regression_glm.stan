data {
  int<lower=0> N; // Number of data points
  int<lower=0> K; // Number of covariates
  int y[N];  // Observations
  matrix[N, K] X; // Covariates
}

parameters {
  real alpha; // Intercept
  vector[K] beta; // Coefficients
}

model {
  alpha ~ normal(0, 2.5);
  beta ~ normal(0, 2.5);
  y ~ bernoulli_logit_glm(X, alpha, beta);
}

generated quantities {
  vector[N] log_lik;
  for ( n in 1:N ) {
    log_lik[n] = bernoulli_logit_lpmf(y[n] | X[n] * beta + alpha);
  }
}
