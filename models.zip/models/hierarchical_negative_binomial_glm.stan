data {
  int<lower=0> N; // Number of data points
  int<lower=1> K; // Number of covariates
  int<lower=1> L; // Number of levels
  int y[N];  // Observations
  array[N] row_vector[K] X; // Covariates
  array[N] int<lower=1, upper=L> ll; // Level index
}

parameters {
  vector[K] mu;
  vector<lower=0>[K] sigma;
  array[L] vector[K] beta_std;
  real recip_theta;
}

transformed parameters {
  array[L] vector[K] beta;
  for (l in 1:L) {
    beta[l] = beta_std[l] .* sigma + mu;
  }
}

model {
  mu ~ normal(0, 2.5);
  sigma ~ exponential(1);
  recip_theta ~ exponential(1);
  for (l in 1:L) {
    beta_std[l] ~ std_normal();
  }
  for ( i in 1:N ) {
    target += neg_binomial_2_log_lpmf(y[i] | X[i] * beta[ll[i]], recip_theta);
  }
}

generated quantities {
  real y_pred[N];
  vector[N] log_lik;
  for ( i in 1:N ) {
    real lin = X[i] * beta[ll[i]];
    y_pred[i] = neg_binomial_2_log_rng(lin, recip_theta);
    log_lik[i] = neg_binomial_2_log_lpmf(y[i] | lin, recip_theta);
  }
}
