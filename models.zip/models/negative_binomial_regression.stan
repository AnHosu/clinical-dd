data {
  int<lower=0> N; // Number of data points
  int y[N];  // Observations
}

parameters {
  real alpha;
  real recip_theta;
}

model {
  alpha ~ normal(0, 2.5);
  recip_theta ~ exponential(1);
  y ~ neg_binomial_2_log(alpha, recip_theta);
}

generated quantities {
  real y_pred[N];
  vector[N] log_lik;
  for ( i in 1:N ) {
    y_pred[i] = neg_binomial_2_log_rng(alpha, recip_theta);
    log_lik[i] = neg_binomial_2_log_lpmf(y[i] | alpha, recip_theta);
  }
}
