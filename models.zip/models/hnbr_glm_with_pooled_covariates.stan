data {
  int<lower=0> N;    // Number of observations
  int<lower=1> K_h;  // Number of hierarchicly pooled covariates
  int<lower=1> K_p;  // Number of completely pooled covariates
  int<lower=1> L;    // Number of levels
  array[N] int y;  // Observations
  array[N] row_vector[K_h] X_h;        // Hierarchicly pooled covariates
  array[N] row_vector[K_p] X_p;        // Completely pooled covariates
  array[N] int<lower=1, upper=L> ll; // Level index
}

parameters {
  vector[K_h] mu;
  vector<lower=0>[K_h] sigma;
  array[L] vector[K_h] beta_std;
  vector[K_p] beta_p;
  real recip_theta;
}

transformed parameters {
  array[L] vector[K_h] beta_h;
  vector[N] x_beta_ll;
  for ( l in 1:L ) {
    beta_h[l] = beta_std[l] .* sigma + mu;
  }
  for ( n in 1:N ) {
    x_beta_ll[n] = X_h[n] * beta_h[ll[n]] + X_p[n] * beta_p;
  }
}

model {
  mu ~ normal(0, 2.5);
  sigma ~ exponential(1);
  beta_p ~ normal(0, 2.5);
  recip_theta ~ exponential(1);
  for (l in 1:L) {
    beta_std[l] ~ std_normal();
  }
  y ~ neg_binomial_2_log(x_beta_ll, recip_theta);
}

generated quantities {
  real y_pred[N];
  vector[N] log_lik;
  for ( n in 1:N ) {
    y_pred[n] = neg_binomial_2_log_rng(x_beta_ll[n], recip_theta);
    log_lik[n] = neg_binomial_2_log_lpmf(y[n] | x_beta_ll[n], recip_theta);
  }
}
