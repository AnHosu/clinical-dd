functions {
  // Zero inflated negative binomial log likelikhood
  real zinb_lpmf(int y,
                 real lambda,
                 real recip_theta,
                 real p) {
    real theta = 1. / recip_theta;
    if (y == 0) {
      return log_sum_exp(
        bernoulli_lpmf(1 | p),
        bernoulli_lpmf(0 | p) + neg_binomial_2_lpmf(0 | lambda, theta)
      );
    } else {
      return bernoulli_lpmf(0 | p) + neg_binomial_2_lpmf(y | lambda, theta);
    }
  }
}

data {
  int<lower=0> N; // Number of data points
  int<lower=0> K; // Number of covariates
  int y[N];  // Observations
  matrix[N, K] X;
}

parameters {
  real alpha_z;
  vector[K] beta_z;
  real alpha_c;
  vector[K] beta_c;
  real recip_theta;
}

transformed parameters {
  vector[N] lambda;
  vector[N] p;
  lambda = exp(X * beta_c + alpha_c);
  p = inv_logit(X * beta_z + alpha_z);
}

model {
  alpha_z ~ normal(0, 2.5);
  alpha_c ~ normal(0, 2.5);
  beta_z ~ normal(0, 2.5);
  beta_c ~ normal(0, 2.5);
  recip_theta ~ exponential(1);
  
  for ( n in 1:N ) {
    target += zinb_lpmf(
      y[n] |
      lambda[n],
      recip_theta,
      p[n]
    );
  }
}

generated quantities {
  vector[N] log_lik;
  for ( n in 1:N ) {
    log_lik[n] = zinb_lpmf(
      y[n] |
      lambda[n],
      recip_theta,
      p[n]
    );
  }
}
