functions {
  // Zero inflated negative binomial log 
  // log link for the zero inflation
  // logit link for the negative binomial
  real zinb_log_logit_lpmf(int y,
                           real alpha_c,
                           real theta,
                           real alpha_z) {
    if (y == 0) {
      return log_sum_exp(
        bernoulli_logit_lpmf(1 | alpha_z),
        bernoulli_logit_lpmf(0 | alpha_z) + neg_binomial_2_log_lpmf(0 | alpha_c, theta)
      );
    } else {
      return bernoulli_logit_lpmf(0 | alpha_z) +
        neg_binomial_2_log_lpmf(y | alpha_c, theta);
    }
  }
}

data {
  int<lower=0> N; // Number of data points
  int y[N];  // Observations
}

parameters {
  real alpha_z;
  real alpha_c;
  real recip_theta;
}

transformed parameters {
  real<lower=0> theta;
  theta = 1. / recip_theta;
}

model {
  alpha_z ~ normal(0, 2.5);
  alpha_c ~ normal(0, 2.5);
  recip_theta ~ exponential(1);
  
  for (n in 1:N) {
    target += zinb_log_logit_lpmf(y[n] | alpha_c, theta, alpha_z);
  }
}

generated quantities {
  real y_pred[N];
  vector[N] log_lik;
  for ( i in 1:N ) {
    int zero = bernoulli_logit_rng(alpha_z);
    y_pred[i] = (1 - zero) * neg_binomial_2_log_rng(alpha_c, theta);
    log_lik[i] = zinb_log_logit_lpmf(y[i] | alpha_c, theta, alpha_z);
  }
}
