data {
  int<lower=0> N;    // Number of observations
  int<lower=1> K_h;  // Number of hierarchicly pooled covariates
  int<lower=1> K_p;  // Number of completely pooled covariates
  int<lower=1> L;    // Number of levels
  array[N] int<lower=0, upper=1> y;  // Observations
  array[N] row_vector[K_h] X_h;        // Hierarchicly pooled covariates
  array[N] row_vector[K_p] X_p;        // Completely pooled covariates
  array[N] int<lower=1, upper=L> ll; // Level index
}

parameters {
  array[K_h] real mu;
  array[K_h] real<lower=0> sigma;
  array[L] vector[K_h] beta_h;
  vector[K_p] beta_p;
}

transformed parameters {
  vector[N] x_beta_ll;
  for (n in 1:N) {
    x_beta_ll[n] = X_h[n] * beta_h[ll[n]] + X_p[n] * beta_p;
  }
}

model {
  mu ~ normal(0, 2.5);
  sigma ~ exponential(1);
  beta_p ~ normal(0, 2.5);
  for (l in 1:L) {
    beta_h[l] ~ normal(mu, sigma);
  }
  y ~ bernoulli_logit(x_beta_ll);
}

generated quantities {
  vector[N] log_lik;
  for (n in 1:N) {
    log_lik[n] = bernoulli_logit_lpmf(y[n] | X_h[n] * beta_h[ll[n]] + X_p[n] * beta_p);
  }
}
