data {
  int<lower=0> N; // Number of data points
  int<lower=1> K; // Number of covariates
  int y[N];  // Observations
  matrix[N, K] X; // Covariates
}

parameters {
  real alpha;
  vector[K] beta;
  real recip_theta;
}

model {
  alpha ~ normal(0, 2.5);
  beta ~ normal(0, 2.5);
  recip_theta ~ exponential(1);
  y ~ neg_binomial_2_log_glm(X, alpha, beta, recip_theta);
}

generated quantities {
  real y_pred[N];
  vector[N] log_lik;
  for ( i in 1:N ) {
    real lin = alpha + X[i] * beta;
    y_pred[i] = neg_binomial_2_log_rng(lin, recip_theta);
    log_lik[i] = neg_binomial_2_log_lpmf(y[i] | lin, recip_theta);
  }
}
